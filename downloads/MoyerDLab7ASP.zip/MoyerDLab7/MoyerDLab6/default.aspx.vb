﻿'Programmer: Dylan Moyer
'CPT 239 - LAB ASSIGNMENT CH 12-15, LAB 7 (DATABASE 02)
'DETAILS VIEW With TEMPLATED FIELDS Using VALIDATION And FK DDL
'Lab 7

Option Explicit On
Option Strict On

Public Class _default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None

    End Sub
    'found on pg 495 in book
    'DataBind refreshes data
    Protected Sub dvBooks_ItemDeleted(sender As Object, e As DetailsViewDeletedEventArgs) Handles dvBooks.ItemDeleted
        gvBooks.DataBind()
    End Sub

    Protected Sub dvBooks_ItemInserted(sender As Object, e As DetailsViewInsertedEventArgs) Handles dvBooks.ItemInserted
        gvBooks.DataBind()
    End Sub

    Protected Sub dvBooks_ItemUpdated(sender As Object, e As DetailsViewUpdatedEventArgs) Handles dvBooks.ItemUpdated
        gvBooks.DataBind()
    End Sub

End Class