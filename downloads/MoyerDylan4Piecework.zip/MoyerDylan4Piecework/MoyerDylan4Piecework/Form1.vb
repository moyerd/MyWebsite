﻿Option Explicit On
Option Strict On

Public Class frmPiecework
    Dim totalNumPieces As Short
    Dim totalPay As Decimal
    Dim numWorkers As Short
    Private Sub frmPiecework_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'shows the date
        Dim dateTime As Date
        Dim dateToday As String

        dateTime = Now()
        dateToday = dateTime.ToString("d")
        tlblDate.Text = dateToday

    End Sub

    Private Sub btnCalulate_Click(sender As Object, e As EventArgs) Handles btnCalulate.Click
        Dim pieces As Short
        Dim pricePerPiece As Decimal
        Dim workersPay As Decimal

        Try
            'Data Valdation
            If txtWorkerName.Text = "" Then
                'error msg name required
                MessageBox.Show("Nothing was entered for Workers name", "Error on Worker's Name", MessageBoxButtons.OK, MessageBoxIcon.Information)
                txtWorkerName.Focus()
            ElseIf txtNumPieces.Text = "" Then 'tested for what we didnt want-bad data
                'error msg data required
                MessageBox.Show("Enter a whole number for amount of pieces", "Error on Number of Pieces", MessageBoxButtons.OK, MessageBoxIcon.Information)
                txtWorkerName.Focus()
            ElseIf Not IsNumeric(txtNumPieces.Text) Then
                'error msg number needed
                MessageBox.Show("Enter Numeric number", "Error on Number of Pieces", MessageBoxButtons.OK, MessageBoxIcon.Information)
                txtWorkerName.Focus()
            ElseIf CDbl(txtNumPieces.Text) <= 0 Then
                'error msg number must be greater than zero
                MessageBox.Show("Enter a whole number greater than zero", "Error on Number of Pieces", MessageBoxButtons.OK, MessageBoxIcon.Information)
                txtWorkerName.Focus()
            ElseIf Math.Ceiling(CDec(txtNumPieces.Text)) <> Math.Floor(CDec(txtNumPieces.Text)) Then
                'error msg only whole numbers allowed
                MessageBox.Show("Enter a whole number", "Error on Number of Pieces", MessageBoxButtons.OK, MessageBoxIcon.Information)
                txtWorkerName.Focus()

            Else
                'input
                pieces = CShort(txtNumPieces.Text)
                'CShort(txtNumPieces.Text) ---opps
                'processing
                Select Case pieces
                    Case 1 To 199
                        pricePerPiece = CDec(0.5)
                    Case 200 To 399
                        pricePerPiece = CDec(0.55)
                    Case 400 To 599
                        pricePerPiece = CDec(0.6)
                    Case Is >= 600
                        pricePerPiece = CDec(0.65)
                End Select

                workersPay = pieces * pricePerPiece
                numWorkers = numWorkers + 1S
                totalPay = totalPay + workersPay
                totalNumPieces = totalNumPieces + pieces

                'hides summary button till btncal is clicked ---- better in form load
                btnSummary.Enabled = True

                'output
                lblWorkerPayOutput.Text = workersPay.ToString("C")
                lblNumWorkersOutput.Text = CStr(numWorkers)
                lblTotalPayOutput.Text = totalPay.ToString("C")
                lblTotalPiecesOutput.Text = CStr(totalNumPieces)



            End If
        Catch ex As Exception
            MessageBox.Show("Unexpected error occured", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try

    End Sub

    Private Sub btnSummary_Click(sender As Object, e As EventArgs) Handles btnSummary.Click
        Dim formattedTotalNumPiecesString As String
        Dim formattedTotalPayString As String
        Dim formattedAvgPayString As String
        Dim messageString As String
        Dim avgPay As Decimal
        'Avg pay for all workers
        avgPay = totalPay / numWorkers

        formattedTotalNumPiecesString = CStr(totalNumPieces)
        formattedTotalPayString = totalPay.ToString("C")
        formattedAvgPayString = avgPay.ToString("C")

        messageString = "Total Number of Pieces: " & formattedTotalNumPiecesString & Environment.NewLine & Environment.NewLine & "Total Pay: " & formattedTotalPayString & Environment.NewLine & Environment.NewLine & "Average Pay: " & formattedAvgPayString
        'Shows numpieces, total pay, avg pay
        MessageBox.Show(messageString, "Summary", MessageBoxButtons.OK, MessageBoxIcon.Information)

    End Sub



    Private Sub btnClearInput_Click(sender As Object, e As EventArgs) Handles btnClearInput.Click
        'Clears input
        With txtWorkerName
            .Focus()
            .Text = ""
        End With
        txtNumPieces.Text = ""
        lblWorkerPayOutput.Text = ""
    End Sub

    Private Sub btnClearAll_Click(sender As Object, e As EventArgs) Handles btnClearAll.Click
        Dim answer As DialogResult
        'prompt user for confirmation

        answer = MessageBox.Show("Are you sure you want to clear ALL information?", "Confirm clearing of All", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)

        'code that clears totals when user says YES
        If answer = Windows.Forms.DialogResult.Yes Then

            'Clears all
            Call btnClearInput_Click(sender, e) 'Calls everything from clear input button


            lblTotalPiecesOutput.Text = ""
            lblTotalPayOutput.Text = ""
            lblNumWorkersOutput.Text = ""

            totalNumPieces = 0
            totalPay = 0
            numWorkers = 0

            btnSummary.Enabled = False

        End If

    End Sub


    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'Closes the program
        Me.Close()
    End Sub


End Class
