﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPiecework
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.staNameDate = New System.Windows.Forms.StatusStrip()
        Me.tlblProgrammer = New System.Windows.Forms.ToolStripStatusLabel()
        Me.tlblDate = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblWorkerName = New System.Windows.Forms.Label()
        Me.lblNumPieces = New System.Windows.Forms.Label()
        Me.txtWorkerName = New System.Windows.Forms.TextBox()
        Me.txtNumPieces = New System.Windows.Forms.TextBox()
        Me.lblWorkerPay = New System.Windows.Forms.Label()
        Me.lblWorkerPayOutput = New System.Windows.Forms.Label()
        Me.btnCalulate = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnSummary = New System.Windows.Forms.Button()
        Me.btnClearInput = New System.Windows.Forms.Button()
        Me.btnClearAll = New System.Windows.Forms.Button()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.gbxSummary = New System.Windows.Forms.GroupBox()
        Me.lblTotalPieces = New System.Windows.Forms.Label()
        Me.lblTotalPay = New System.Windows.Forms.Label()
        Me.lblNumWorkers = New System.Windows.Forms.Label()
        Me.lblTotalPiecesOutput = New System.Windows.Forms.Label()
        Me.lblTotalPayOutput = New System.Windows.Forms.Label()
        Me.lblNumWorkersOutput = New System.Windows.Forms.Label()
        Me.staNameDate.SuspendLayout()
        Me.gbxSummary.SuspendLayout()
        Me.SuspendLayout()
        '
        'staNameDate
        '
        Me.staNameDate.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tlblProgrammer, Me.tlblDate})
        Me.staNameDate.Location = New System.Drawing.Point(0, 315)
        Me.staNameDate.Name = "staNameDate"
        Me.staNameDate.Size = New System.Drawing.Size(255, 22)
        Me.staNameDate.TabIndex = 13
        Me.staNameDate.Text = "StatusStrip1"
        '
        'tlblProgrammer
        '
        Me.tlblProgrammer.Name = "tlblProgrammer"
        Me.tlblProgrammer.Size = New System.Drawing.Size(166, 17)
        Me.tlblProgrammer.Text = "Programmed by: Dylan Moyer"
        '
        'tlblDate
        '
        Me.tlblDate.Name = "tlblDate"
        Me.tlblDate.Size = New System.Drawing.Size(0, 17)
        '
        'lblWorkerName
        '
        Me.lblWorkerName.AutoSize = True
        Me.lblWorkerName.Location = New System.Drawing.Point(21, 33)
        Me.lblWorkerName.Name = "lblWorkerName"
        Me.lblWorkerName.Size = New System.Drawing.Size(83, 13)
        Me.lblWorkerName.TabIndex = 1
        Me.lblWorkerName.Text = "Worker's Name:"
        '
        'lblNumPieces
        '
        Me.lblNumPieces.AutoSize = True
        Me.lblNumPieces.Location = New System.Drawing.Point(21, 60)
        Me.lblNumPieces.Name = "lblNumPieces"
        Me.lblNumPieces.Size = New System.Drawing.Size(96, 13)
        Me.lblNumPieces.TabIndex = 3
        Me.lblNumPieces.Text = "Number Of Pieces:"
        '
        'txtWorkerName
        '
        Me.txtWorkerName.Location = New System.Drawing.Point(132, 30)
        Me.txtWorkerName.Name = "txtWorkerName"
        Me.txtWorkerName.Size = New System.Drawing.Size(100, 20)
        Me.txtWorkerName.TabIndex = 2
        '
        'txtNumPieces
        '
        Me.txtNumPieces.Location = New System.Drawing.Point(132, 57)
        Me.txtNumPieces.Name = "txtNumPieces"
        Me.txtNumPieces.Size = New System.Drawing.Size(100, 20)
        Me.txtNumPieces.TabIndex = 4
        '
        'lblWorkerPay
        '
        Me.lblWorkerPay.AutoSize = True
        Me.lblWorkerPay.Location = New System.Drawing.Point(21, 89)
        Me.lblWorkerPay.Name = "lblWorkerPay"
        Me.lblWorkerPay.Size = New System.Drawing.Size(73, 13)
        Me.lblWorkerPay.TabIndex = 5
        Me.lblWorkerPay.Text = "Worker's Pay:"
        '
        'lblWorkerPayOutput
        '
        Me.lblWorkerPayOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblWorkerPayOutput.Location = New System.Drawing.Point(132, 88)
        Me.lblWorkerPayOutput.Name = "lblWorkerPayOutput"
        Me.lblWorkerPayOutput.Size = New System.Drawing.Size(100, 23)
        Me.lblWorkerPayOutput.TabIndex = 6
        '
        'btnCalulate
        '
        Me.btnCalulate.Location = New System.Drawing.Point(20, 227)
        Me.btnCalulate.Name = "btnCalulate"
        Me.btnCalulate.Size = New System.Drawing.Size(103, 24)
        Me.btnCalulate.TabIndex = 8
        Me.btnCalulate.Text = "&Calulate"
        Me.btnCalulate.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(129, 287)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(103, 24)
        Me.btnExit.TabIndex = 12
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnSummary
        '
        Me.btnSummary.Enabled = False
        Me.btnSummary.Location = New System.Drawing.Point(129, 227)
        Me.btnSummary.Name = "btnSummary"
        Me.btnSummary.Size = New System.Drawing.Size(103, 24)
        Me.btnSummary.TabIndex = 9
        Me.btnSummary.Text = "S&ummary"
        Me.btnSummary.UseVisualStyleBackColor = True
        '
        'btnClearInput
        '
        Me.btnClearInput.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnClearInput.Location = New System.Drawing.Point(20, 257)
        Me.btnClearInput.Name = "btnClearInput"
        Me.btnClearInput.Size = New System.Drawing.Size(103, 24)
        Me.btnClearInput.TabIndex = 10
        Me.btnClearInput.Text = "Clear I&nput"
        Me.btnClearInput.UseVisualStyleBackColor = True
        '
        'btnClearAll
        '
        Me.btnClearAll.Location = New System.Drawing.Point(129, 257)
        Me.btnClearAll.Name = "btnClearAll"
        Me.btnClearAll.Size = New System.Drawing.Size(103, 24)
        Me.btnClearAll.TabIndex = 11
        Me.btnClearAll.Text = "Clear &All"
        Me.btnClearAll.UseVisualStyleBackColor = True
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(74, 3)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(107, 24)
        Me.lblTitle.TabIndex = 0
        Me.lblTitle.Text = "Piecework"
        '
        'gbxSummary
        '
        Me.gbxSummary.Controls.Add(Me.lblNumWorkersOutput)
        Me.gbxSummary.Controls.Add(Me.lblTotalPayOutput)
        Me.gbxSummary.Controls.Add(Me.lblTotalPiecesOutput)
        Me.gbxSummary.Controls.Add(Me.lblNumWorkers)
        Me.gbxSummary.Controls.Add(Me.lblTotalPay)
        Me.gbxSummary.Controls.Add(Me.lblTotalPieces)
        Me.gbxSummary.Location = New System.Drawing.Point(15, 114)
        Me.gbxSummary.Name = "gbxSummary"
        Me.gbxSummary.Size = New System.Drawing.Size(229, 107)
        Me.gbxSummary.TabIndex = 7
        Me.gbxSummary.TabStop = False
        Me.gbxSummary.Text = "Summary"
        '
        'lblTotalPieces
        '
        Me.lblTotalPieces.AutoSize = True
        Me.lblTotalPieces.Location = New System.Drawing.Point(6, 16)
        Me.lblTotalPieces.Name = "lblTotalPieces"
        Me.lblTotalPieces.Size = New System.Drawing.Size(69, 13)
        Me.lblTotalPieces.TabIndex = 0
        Me.lblTotalPieces.Text = "Total Pieces:"
        '
        'lblTotalPay
        '
        Me.lblTotalPay.AutoSize = True
        Me.lblTotalPay.Location = New System.Drawing.Point(6, 44)
        Me.lblTotalPay.Name = "lblTotalPay"
        Me.lblTotalPay.Size = New System.Drawing.Size(55, 13)
        Me.lblTotalPay.TabIndex = 2
        Me.lblTotalPay.Text = "Total Pay:"
        '
        'lblNumWorkers
        '
        Me.lblNumWorkers.AutoSize = True
        Me.lblNumWorkers.Location = New System.Drawing.Point(6, 72)
        Me.lblNumWorkers.Name = "lblNumWorkers"
        Me.lblNumWorkers.Size = New System.Drawing.Size(102, 13)
        Me.lblNumWorkers.TabIndex = 4
        Me.lblNumWorkers.Text = "Number of Workers:"
        '
        'lblTotalPiecesOutput
        '
        Me.lblTotalPiecesOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotalPiecesOutput.Location = New System.Drawing.Point(117, 15)
        Me.lblTotalPiecesOutput.Name = "lblTotalPiecesOutput"
        Me.lblTotalPiecesOutput.Size = New System.Drawing.Size(100, 23)
        Me.lblTotalPiecesOutput.TabIndex = 1
        '
        'lblTotalPayOutput
        '
        Me.lblTotalPayOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotalPayOutput.Location = New System.Drawing.Point(117, 43)
        Me.lblTotalPayOutput.Name = "lblTotalPayOutput"
        Me.lblTotalPayOutput.Size = New System.Drawing.Size(100, 23)
        Me.lblTotalPayOutput.TabIndex = 3
        '
        'lblNumWorkersOutput
        '
        Me.lblNumWorkersOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblNumWorkersOutput.Location = New System.Drawing.Point(117, 71)
        Me.lblNumWorkersOutput.Name = "lblNumWorkersOutput"
        Me.lblNumWorkersOutput.Size = New System.Drawing.Size(100, 23)
        Me.lblNumWorkersOutput.TabIndex = 5
        '
        'frmPiecework
        '
        Me.AcceptButton = Me.btnCalulate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnClearInput
        Me.ClientSize = New System.Drawing.Size(255, 337)
        Me.Controls.Add(Me.gbxSummary)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.btnClearAll)
        Me.Controls.Add(Me.btnClearInput)
        Me.Controls.Add(Me.btnSummary)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalulate)
        Me.Controls.Add(Me.txtNumPieces)
        Me.Controls.Add(Me.lblWorkerPayOutput)
        Me.Controls.Add(Me.lblWorkerPay)
        Me.Controls.Add(Me.txtWorkerName)
        Me.Controls.Add(Me.lblNumPieces)
        Me.Controls.Add(Me.lblWorkerName)
        Me.Controls.Add(Me.staNameDate)
        Me.Name = "frmPiecework"
        Me.Text = "Piecework"
        Me.staNameDate.ResumeLayout(False)
        Me.staNameDate.PerformLayout()
        Me.gbxSummary.ResumeLayout(False)
        Me.gbxSummary.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents staNameDate As System.Windows.Forms.StatusStrip
    Friend WithEvents tlblProgrammer As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents tlblDate As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblWorkerName As System.Windows.Forms.Label
    Friend WithEvents lblNumPieces As System.Windows.Forms.Label
    Friend WithEvents txtWorkerName As System.Windows.Forms.TextBox
    Friend WithEvents txtNumPieces As System.Windows.Forms.TextBox
    Friend WithEvents lblWorkerPay As System.Windows.Forms.Label
    Friend WithEvents lblWorkerPayOutput As System.Windows.Forms.Label
    Friend WithEvents btnCalulate As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents btnSummary As System.Windows.Forms.Button
    Friend WithEvents btnClearInput As System.Windows.Forms.Button
    Friend WithEvents btnClearAll As System.Windows.Forms.Button
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents gbxSummary As System.Windows.Forms.GroupBox
    Friend WithEvents lblNumWorkersOutput As System.Windows.Forms.Label
    Friend WithEvents lblTotalPayOutput As System.Windows.Forms.Label
    Friend WithEvents lblTotalPiecesOutput As System.Windows.Forms.Label
    Friend WithEvents lblNumWorkers As System.Windows.Forms.Label
    Friend WithEvents lblTotalPay As System.Windows.Forms.Label
    Friend WithEvents lblTotalPieces As System.Windows.Forms.Label

End Class
