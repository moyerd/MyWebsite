﻿'Programmer: Dylan Moyer
'Project: Number Conversion between Binary and Decimal
'Lab 3

Option Strict On
Option Explicit On

Public Class _default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None
    End Sub

    Protected Sub btnConvert_Click(sender As Object, e As EventArgs) Handles btnConvert.Click
        Dim Bin As Integer
        Dim Output As String = ""
        Dim Input As Integer

        Try
            If IsValid = True Then
                Input = CInt(txtDecInput.Text)

                While Input <> 0
                    If Input Mod 2 = 0 Then
                        Bin = 0
                    Else
                        Bin = 1
                    End If
                    Input \= 2
                    Output = Bin.ToString() & Output
                End While
                If Output Is Nothing Then
                    Output = CStr(0)
                Else
                    lblOutput.Text = Output
                End If
                If chkDigits.Checked = True Then
                    Output = Output.PadLeft(8, CChar("0"))
                    lblOutput.Text = Output
                End If
            End If

        Catch ex As Exception
            lblBigError.Text = "Invalid Data"
        End Try
    End Sub
End Class