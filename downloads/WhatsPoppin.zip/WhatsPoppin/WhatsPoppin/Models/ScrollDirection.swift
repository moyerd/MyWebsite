//
//  ScrollDirection.swift

import Foundation
enum ScrollDirection {
    case up
    case down
}
