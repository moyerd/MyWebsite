﻿'Dylan Moyer
'Commission
'Chapter 7 Lab Assignment
Option Explicit On
Option Strict On

Public Class frmSummary


    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnHide.Click
        Me.Hide()
    End Sub

    Private Sub frmSummary_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        lblTotalSalesOutput.Text = frmMain.Pubtotalsales.ToString("C")
        lblTotalCommissionOutput.Text = frmMain.Pubcommission.ToString("C")
        lblTotalPayOutput.Text = frmMain.PubPaytotal.ToString("C")

    End Sub
End Class