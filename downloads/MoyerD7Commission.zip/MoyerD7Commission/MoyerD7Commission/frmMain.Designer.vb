﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.mnusMain = New System.Windows.Forms.MenuStrip()
        Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuPay = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSummary = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuEdit = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuClearPerson = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuClearAll = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFont = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFontBackColor = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuAbout = New System.Windows.Forms.ToolStripMenuItem()
        Me.stsaNameDate = New System.Windows.Forms.StatusStrip()
        Me.tlblProgrammer = New System.Windows.Forms.ToolStripStatusLabel()
        Me.tlblDate = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblSalesPerson = New System.Windows.Forms.Label()
        Me.lblSales = New System.Windows.Forms.Label()
        Me.txtSalesPerson = New System.Windows.Forms.TextBox()
        Me.txtSales = New System.Windows.Forms.TextBox()
        Me.lblPay = New System.Windows.Forms.Label()
        Me.lblPayOutput = New System.Windows.Forms.Label()
        Me.dlgFont = New System.Windows.Forms.FontDialog()
        Me.dlgColor = New System.Windows.Forms.ColorDialog()
        Me.tsrMain = New System.Windows.Forms.ToolStrip()
        Me.tsbPay = New System.Windows.Forms.ToolStripButton()
        Me.tsbSummary = New System.Windows.Forms.ToolStripButton()
        Me.tsbFont = New System.Windows.Forms.ToolStripButton()
        Me.tsbFontBackColor = New System.Windows.Forms.ToolStripButton()
        Me.tsbClearPerson = New System.Windows.Forms.ToolStripButton()
        Me.tsbClearAll = New System.Windows.Forms.ToolStripButton()
        Me.tsbAbout = New System.Windows.Forms.ToolStripButton()
        Me.tsbExit = New System.Windows.Forms.ToolStripButton()
        Me.mnusMain.SuspendLayout()
        Me.stsaNameDate.SuspendLayout()
        Me.tsrMain.SuspendLayout()
        Me.SuspendLayout()
        '
        'mnusMain
        '
        Me.mnusMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile, Me.mnuEdit, Me.mnuHelp})
        Me.mnusMain.Location = New System.Drawing.Point(0, 0)
        Me.mnusMain.Name = "mnusMain"
        Me.mnusMain.Size = New System.Drawing.Size(303, 24)
        Me.mnusMain.TabIndex = 0
        Me.mnusMain.Text = "MenuStrip1"
        '
        'mnuFile
        '
        Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuPay, Me.mnuSummary, Me.mnuExit})
        Me.mnuFile.Name = "mnuFile"
        Me.mnuFile.Size = New System.Drawing.Size(37, 20)
        Me.mnuFile.Text = "&File"
        '
        'mnuPay
        '
        Me.mnuPay.Name = "mnuPay"
        Me.mnuPay.Size = New System.Drawing.Size(152, 22)
        Me.mnuPay.Text = "&Pay"
        '
        'mnuSummary
        '
        Me.mnuSummary.Enabled = False
        Me.mnuSummary.Name = "mnuSummary"
        Me.mnuSummary.Size = New System.Drawing.Size(152, 22)
        Me.mnuSummary.Text = "&Summary"
        '
        'mnuExit
        '
        Me.mnuExit.Name = "mnuExit"
        Me.mnuExit.Size = New System.Drawing.Size(152, 22)
        Me.mnuExit.Text = "E&xit"
        '
        'mnuEdit
        '
        Me.mnuEdit.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuClearPerson, Me.mnuClearAll, Me.mnuFont, Me.mnuFontBackColor})
        Me.mnuEdit.Name = "mnuEdit"
        Me.mnuEdit.Size = New System.Drawing.Size(39, 20)
        Me.mnuEdit.Text = "&Edit"
        '
        'mnuClearPerson
        '
        Me.mnuClearPerson.Name = "mnuClearPerson"
        Me.mnuClearPerson.Size = New System.Drawing.Size(158, 22)
        Me.mnuClearPerson.Text = "C&lear Person"
        '
        'mnuClearAll
        '
        Me.mnuClearAll.Enabled = False
        Me.mnuClearAll.Name = "mnuClearAll"
        Me.mnuClearAll.Size = New System.Drawing.Size(158, 22)
        Me.mnuClearAll.Text = "Clea&r All"
        '
        'mnuFont
        '
        Me.mnuFont.Name = "mnuFont"
        Me.mnuFont.Size = New System.Drawing.Size(158, 22)
        Me.mnuFont.Text = "Fo&nt"
        '
        'mnuFontBackColor
        '
        Me.mnuFontBackColor.Name = "mnuFontBackColor"
        Me.mnuFontBackColor.Size = New System.Drawing.Size(158, 22)
        Me.mnuFontBackColor.Text = "Font Back C&olor"
        '
        'mnuHelp
        '
        Me.mnuHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuAbout})
        Me.mnuHelp.Name = "mnuHelp"
        Me.mnuHelp.Size = New System.Drawing.Size(44, 20)
        Me.mnuHelp.Text = "&Help"
        '
        'mnuAbout
        '
        Me.mnuAbout.Name = "mnuAbout"
        Me.mnuAbout.Size = New System.Drawing.Size(152, 22)
        Me.mnuAbout.Text = "&About"
        '
        'stsaNameDate
        '
        Me.stsaNameDate.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tlblProgrammer, Me.tlblDate})
        Me.stsaNameDate.Location = New System.Drawing.Point(0, 210)
        Me.stsaNameDate.Name = "stsaNameDate"
        Me.stsaNameDate.Size = New System.Drawing.Size(303, 22)
        Me.stsaNameDate.TabIndex = 8
        Me.stsaNameDate.Text = "StatusStrip1"
        '
        'tlblProgrammer
        '
        Me.tlblProgrammer.Name = "tlblProgrammer"
        Me.tlblProgrammer.Size = New System.Drawing.Size(166, 17)
        Me.tlblProgrammer.Text = "Programmed By: Dylan Moyer"
        '
        'tlblDate
        '
        Me.tlblDate.Name = "tlblDate"
        Me.tlblDate.Size = New System.Drawing.Size(0, 17)
        '
        'lblSalesPerson
        '
        Me.lblSalesPerson.AutoSize = True
        Me.lblSalesPerson.Location = New System.Drawing.Point(12, 88)
        Me.lblSalesPerson.Name = "lblSalesPerson"
        Me.lblSalesPerson.Size = New System.Drawing.Size(103, 13)
        Me.lblSalesPerson.TabIndex = 2
        Me.lblSalesPerson.Text = "Sales Person Name:"
        '
        'lblSales
        '
        Me.lblSales.AutoSize = True
        Me.lblSales.Location = New System.Drawing.Point(76, 124)
        Me.lblSales.Name = "lblSales"
        Me.lblSales.Size = New System.Drawing.Size(36, 13)
        Me.lblSales.TabIndex = 4
        Me.lblSales.Text = "Sales:"
        '
        'txtSalesPerson
        '
        Me.txtSalesPerson.Location = New System.Drawing.Point(118, 85)
        Me.txtSalesPerson.Name = "txtSalesPerson"
        Me.txtSalesPerson.Size = New System.Drawing.Size(100, 20)
        Me.txtSalesPerson.TabIndex = 3
        '
        'txtSales
        '
        Me.txtSales.Location = New System.Drawing.Point(118, 121)
        Me.txtSales.Name = "txtSales"
        Me.txtSales.Size = New System.Drawing.Size(100, 20)
        Me.txtSales.TabIndex = 5
        '
        'lblPay
        '
        Me.lblPay.AutoSize = True
        Me.lblPay.Location = New System.Drawing.Point(84, 159)
        Me.lblPay.Name = "lblPay"
        Me.lblPay.Size = New System.Drawing.Size(28, 13)
        Me.lblPay.TabIndex = 6
        Me.lblPay.Text = "Pay:"
        '
        'lblPayOutput
        '
        Me.lblPayOutput.BackColor = System.Drawing.Color.Transparent
        Me.lblPayOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblPayOutput.Location = New System.Drawing.Point(118, 158)
        Me.lblPayOutput.Name = "lblPayOutput"
        Me.lblPayOutput.Size = New System.Drawing.Size(100, 29)
        Me.lblPayOutput.TabIndex = 7
        '
        'dlgFont
        '
        Me.dlgFont.ShowColor = True
        Me.dlgFont.ShowHelp = True
        '
        'dlgColor
        '
        Me.dlgColor.ShowHelp = True
        '
        'tsrMain
        '
        Me.tsrMain.ImageScalingSize = New System.Drawing.Size(29, 29)
        Me.tsrMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsbPay, Me.tsbSummary, Me.tsbFont, Me.tsbFontBackColor, Me.tsbClearPerson, Me.tsbClearAll, Me.tsbAbout, Me.tsbExit})
        Me.tsrMain.Location = New System.Drawing.Point(0, 24)
        Me.tsrMain.Name = "tsrMain"
        Me.tsrMain.Size = New System.Drawing.Size(303, 36)
        Me.tsrMain.TabIndex = 1
        Me.tsrMain.Text = "ToolStrip1"
        '
        'tsbPay
        '
        Me.tsbPay.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbPay.Image = CType(resources.GetObject("tsbPay.Image"), System.Drawing.Image)
        Me.tsbPay.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbPay.Name = "tsbPay"
        Me.tsbPay.Size = New System.Drawing.Size(33, 33)
        Me.tsbPay.Text = "Pay"
        '
        'tsbSummary
        '
        Me.tsbSummary.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbSummary.Enabled = False
        Me.tsbSummary.Image = CType(resources.GetObject("tsbSummary.Image"), System.Drawing.Image)
        Me.tsbSummary.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbSummary.Name = "tsbSummary"
        Me.tsbSummary.Size = New System.Drawing.Size(33, 33)
        Me.tsbSummary.Text = "Summary"
        '
        'tsbFont
        '
        Me.tsbFont.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbFont.Image = CType(resources.GetObject("tsbFont.Image"), System.Drawing.Image)
        Me.tsbFont.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbFont.Name = "tsbFont"
        Me.tsbFont.Size = New System.Drawing.Size(33, 33)
        Me.tsbFont.Text = "Font"
        '
        'tsbFontBackColor
        '
        Me.tsbFontBackColor.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbFontBackColor.Image = CType(resources.GetObject("tsbFontBackColor.Image"), System.Drawing.Image)
        Me.tsbFontBackColor.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbFontBackColor.Name = "tsbFontBackColor"
        Me.tsbFontBackColor.Size = New System.Drawing.Size(33, 33)
        Me.tsbFontBackColor.Text = "Font Back Color"
        '
        'tsbClearPerson
        '
        Me.tsbClearPerson.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbClearPerson.Image = CType(resources.GetObject("tsbClearPerson.Image"), System.Drawing.Image)
        Me.tsbClearPerson.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbClearPerson.Name = "tsbClearPerson"
        Me.tsbClearPerson.Size = New System.Drawing.Size(33, 33)
        Me.tsbClearPerson.Text = "Clear Person"
        '
        'tsbClearAll
        '
        Me.tsbClearAll.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbClearAll.Enabled = False
        Me.tsbClearAll.Image = CType(resources.GetObject("tsbClearAll.Image"), System.Drawing.Image)
        Me.tsbClearAll.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbClearAll.Name = "tsbClearAll"
        Me.tsbClearAll.Size = New System.Drawing.Size(33, 33)
        Me.tsbClearAll.Text = "Clear All"
        '
        'tsbAbout
        '
        Me.tsbAbout.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbAbout.Image = CType(resources.GetObject("tsbAbout.Image"), System.Drawing.Image)
        Me.tsbAbout.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbAbout.Name = "tsbAbout"
        Me.tsbAbout.Size = New System.Drawing.Size(33, 33)
        Me.tsbAbout.Text = "About"
        '
        'tsbExit
        '
        Me.tsbExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsbExit.Image = CType(resources.GetObject("tsbExit.Image"), System.Drawing.Image)
        Me.tsbExit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsbExit.Name = "tsbExit"
        Me.tsbExit.Size = New System.Drawing.Size(33, 33)
        Me.tsbExit.Text = "Exit"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(303, 232)
        Me.Controls.Add(Me.tsrMain)
        Me.Controls.Add(Me.lblPayOutput)
        Me.Controls.Add(Me.lblPay)
        Me.Controls.Add(Me.txtSales)
        Me.Controls.Add(Me.txtSalesPerson)
        Me.Controls.Add(Me.lblSales)
        Me.Controls.Add(Me.lblSalesPerson)
        Me.Controls.Add(Me.stsaNameDate)
        Me.Controls.Add(Me.mnusMain)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.mnusMain
        Me.Name = "frmMain"
        Me.Text = "Main Commission"
        Me.mnusMain.ResumeLayout(False)
        Me.mnusMain.PerformLayout()
        Me.stsaNameDate.ResumeLayout(False)
        Me.stsaNameDate.PerformLayout()
        Me.tsrMain.ResumeLayout(False)
        Me.tsrMain.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents mnusMain As System.Windows.Forms.MenuStrip
    Friend WithEvents mnuFile As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuPay As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSummary As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuExit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuEdit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuClearPerson As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuClearAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuHelp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuAbout As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents stsaNameDate As System.Windows.Forms.StatusStrip
    Friend WithEvents tlblProgrammer As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents tlblDate As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents lblSalesPerson As System.Windows.Forms.Label
    Friend WithEvents lblSales As System.Windows.Forms.Label
    Friend WithEvents txtSalesPerson As System.Windows.Forms.TextBox
    Friend WithEvents txtSales As System.Windows.Forms.TextBox
    Friend WithEvents lblPay As System.Windows.Forms.Label
    Friend WithEvents lblPayOutput As System.Windows.Forms.Label
    Friend WithEvents mnuFont As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFontBackColor As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents dlgFont As System.Windows.Forms.FontDialog
    Friend WithEvents dlgColor As System.Windows.Forms.ColorDialog
    Friend WithEvents tsrMain As System.Windows.Forms.ToolStrip
    Friend WithEvents tsbPay As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbSummary As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbFont As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbFontBackColor As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbClearPerson As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbClearAll As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbAbout As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsbExit As System.Windows.Forms.ToolStripButton

End Class
