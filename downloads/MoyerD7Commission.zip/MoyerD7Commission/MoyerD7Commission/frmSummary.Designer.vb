﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSummary
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSummary))
        Me.lblTotalSales = New System.Windows.Forms.Label()
        Me.lblTotalCommission = New System.Windows.Forms.Label()
        Me.lblTotalPay = New System.Windows.Forms.Label()
        Me.lblTotalSalesOutput = New System.Windows.Forms.Label()
        Me.lblTotalCommissionOutput = New System.Windows.Forms.Label()
        Me.lblTotalPayOutput = New System.Windows.Forms.Label()
        Me.btnHide = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblTotalSales
        '
        Me.lblTotalSales.AutoSize = True
        Me.lblTotalSales.Location = New System.Drawing.Point(47, 32)
        Me.lblTotalSales.Name = "lblTotalSales"
        Me.lblTotalSales.Size = New System.Drawing.Size(63, 13)
        Me.lblTotalSales.TabIndex = 0
        Me.lblTotalSales.Text = "Total Sales:"
        '
        'lblTotalCommission
        '
        Me.lblTotalCommission.AutoSize = True
        Me.lblTotalCommission.Location = New System.Drawing.Point(18, 72)
        Me.lblTotalCommission.Name = "lblTotalCommission"
        Me.lblTotalCommission.Size = New System.Drawing.Size(92, 13)
        Me.lblTotalCommission.TabIndex = 2
        Me.lblTotalCommission.Text = "Total Commission:"
        '
        'lblTotalPay
        '
        Me.lblTotalPay.AutoSize = True
        Me.lblTotalPay.Location = New System.Drawing.Point(55, 110)
        Me.lblTotalPay.Name = "lblTotalPay"
        Me.lblTotalPay.Size = New System.Drawing.Size(55, 13)
        Me.lblTotalPay.TabIndex = 4
        Me.lblTotalPay.Text = "Total Pay:"
        '
        'lblTotalSalesOutput
        '
        Me.lblTotalSalesOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotalSalesOutput.Location = New System.Drawing.Point(125, 31)
        Me.lblTotalSalesOutput.Name = "lblTotalSalesOutput"
        Me.lblTotalSalesOutput.Size = New System.Drawing.Size(90, 22)
        Me.lblTotalSalesOutput.TabIndex = 1
        '
        'lblTotalCommissionOutput
        '
        Me.lblTotalCommissionOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotalCommissionOutput.Location = New System.Drawing.Point(125, 71)
        Me.lblTotalCommissionOutput.Name = "lblTotalCommissionOutput"
        Me.lblTotalCommissionOutput.Size = New System.Drawing.Size(90, 22)
        Me.lblTotalCommissionOutput.TabIndex = 3
        '
        'lblTotalPayOutput
        '
        Me.lblTotalPayOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotalPayOutput.Location = New System.Drawing.Point(125, 109)
        Me.lblTotalPayOutput.Name = "lblTotalPayOutput"
        Me.lblTotalPayOutput.Size = New System.Drawing.Size(90, 22)
        Me.lblTotalPayOutput.TabIndex = 5
        '
        'btnHide
        '
        Me.btnHide.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnHide.Location = New System.Drawing.Point(140, 151)
        Me.btnHide.Name = "btnHide"
        Me.btnHide.Size = New System.Drawing.Size(75, 23)
        Me.btnHide.TabIndex = 6
        Me.btnHide.Text = "&Hide"
        Me.btnHide.UseVisualStyleBackColor = True
        '
        'frmSummary
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnHide
        Me.ClientSize = New System.Drawing.Size(249, 199)
        Me.Controls.Add(Me.btnHide)
        Me.Controls.Add(Me.lblTotalPayOutput)
        Me.Controls.Add(Me.lblTotalCommissionOutput)
        Me.Controls.Add(Me.lblTotalSalesOutput)
        Me.Controls.Add(Me.lblTotalPay)
        Me.Controls.Add(Me.lblTotalCommission)
        Me.Controls.Add(Me.lblTotalSales)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmSummary"
        Me.Text = "Summary"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblTotalSales As System.Windows.Forms.Label
    Friend WithEvents lblTotalCommission As System.Windows.Forms.Label
    Friend WithEvents lblTotalPay As System.Windows.Forms.Label
    Friend WithEvents lblTotalSalesOutput As System.Windows.Forms.Label
    Friend WithEvents lblTotalCommissionOutput As System.Windows.Forms.Label
    Friend WithEvents lblTotalPayOutput As System.Windows.Forms.Label
    Friend WithEvents btnHide As System.Windows.Forms.Button
End Class
