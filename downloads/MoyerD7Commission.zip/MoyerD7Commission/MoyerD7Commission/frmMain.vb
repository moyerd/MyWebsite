﻿'Dylan Moyer
'Commission
'Chapter 7 Lab Assignment

Option Explicit On
Option Strict On

Public Class frmMain
    Public PubPaytotal As Decimal
    Public Pubcommission As Decimal
    Public Pubtotalsales As Decimal

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim dateTime As Date


        dateTime = Now()
        tlblDate.Text = dateTime.ToString("d")
    End Sub
    Private Function FuncContinue() As Boolean
        Dim Valid As Boolean

        'txtSalesPerson
        If txtSalesPerson.Text = "" Then
            MessageBox.Show("Nothing was entered", "Error on Sales Person Name", MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtSalesPerson.Focus()
        ElseIf IsNumeric(txtSalesPerson.Text) = True Then
            MessageBox.Show("Don't Put a number in the field Sales Person Name", "Error on Sales Person Name", MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtSalesPerson.Focus()
            'txtSales
        ElseIf txtSales.Text = "" Then
            MessageBox.Show("Nothing was entered", "Error on Sales", MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtSales.Focus()
        ElseIf IsNumeric(txtSales.Text) = False Then
            MessageBox.Show("Please put a number in the field Sales", "Error on Sales ", MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtSales.Focus()
        ElseIf CDbl(txtSales.Text) <= 0 Then
            MessageBox.Show("Please input a sales amount greater than 0", "Error on Sales ", MessageBoxButtons.OK, MessageBoxIcon.Information)
            txtSales.Focus()
        Else
            Valid = True
        End If

        Return Valid
    End Function

    Function commission(ByVal funcSales As Decimal) As Decimal
        Dim commissionForSale As Decimal
        Const Quota As Decimal = 1000
        Const commissionRate As Decimal = CDec(0.15)

        If funcSales >= Quota Then
            commissionForSale = funcSales * commissionRate
        Else
            commissionForSale = 0
        End If

        Return commissionForSale
    End Function



    Private Sub mnuPay_Click(sender As Object, e As EventArgs) Handles mnuPay.Click
        Dim funcValidation As Boolean
        Const basePay As Decimal = 250

        Dim sales As Decimal
        Dim comAmount As Decimal
        Dim Pay As Decimal

        Try

            funcValidation = FuncContinue()
            If funcValidation = True Then
                'input
                sales = CDec(txtSales.Text)
                comAmount = commission(sales)

                'processing

                Pay = basePay + comAmount

                Pubtotalsales = Pubtotalsales + sales

                PubPaytotal = PubPaytotal + Pay
                Pubcommission = Pubcommission + comAmount

                'output
                lblPayOutput.Text = Pay.ToString("C")

                mnuSummary.Enabled = True
                mnuClearAll.Enabled = True
                tsbSummary.Enabled = True
                tsbClearAll.Enabled = True
                txtSalesPerson.Focus()
            End If
        Catch ex As Exception
            MessageBox.Show("Unexpected error occured", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtSalesPerson.Focus()
        End Try
    End Sub

    Private Sub mnuExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click
        Dim answer As DialogResult
        'prompt user for confirmation

        answer = MessageBox.Show("Are you sure you want to Exit", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)


        If answer = Windows.Forms.DialogResult.Yes Then
            Me.Close()
        End If
    End Sub

    Private Sub mnuAbout_Click(sender As Object, e As EventArgs) Handles mnuAbout.Click
        frmAbout.ShowDialog()
    End Sub
    Private Sub mnuSummary_Click(sender As Object, e As EventArgs) Handles mnuSummary.Click
        frmSummary.ShowDialog()
    End Sub
    Private Sub mnuFont_Click(sender As Object, e As EventArgs) Handles mnuFont.Click
        'display the font dialog
        'take the user entered values and applay them to lblTotalPayOutput
        If dlgFont.ShowDialog() = Windows.Forms.DialogResult.OK Then
            lblPayOutput.Font = dlgFont.Font
            lblPayOutput.ForeColor = dlgFont.Color
        End If

    End Sub

    Private Sub mnuFontBackColor_Click(sender As Object, e As EventArgs) Handles mnuFontBackColor.Click
        'display the color dialog
        'take the user enterd values and apply them to lblTotalPayOutput
        If dlgColor.ShowDialog() = Windows.Forms.DialogResult.OK Then
            'set the back color of lblTotalpayOutput
            lblPayOutput.BackColor = dlgColor.Color
        End If
    End Sub

    Private Sub mnuClearPerson_Click(sender As Object, e As EventArgs) Handles mnuClearPerson.Click

        With txtSalesPerson
            .Focus()
            .Text = ""
        End With
        txtSales.Text = ""
        lblPayOutput.Text = ""

    End Sub

    Private Sub mnuClearAll_Click(sender As Object, e As EventArgs) Handles mnuClearAll.Click
        Dim answer As DialogResult
        'prompt user for confirmation

        answer = MessageBox.Show("Are you sure you want to clear ALL?", "Clear all", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)


        If answer = Windows.Forms.DialogResult.Yes Then
            Call mnuClearPerson_Click(sender, e)

            PubPaytotal = 0
            Pubcommission = 0
            Pubtotalsales = 0

            mnuClearAll.Enabled = False
            mnuSummary.Enabled = False
            tsbClearAll.Enabled = False
            tsbSummary.Enabled = False

        End If
    End Sub

    Private Sub tsbPay_Click(sender As Object, e As EventArgs) Handles tsbPay.Click
        Call mnuPay_Click(sender, e)
    End Sub

    Private Sub tsbSummary_Click(sender As Object, e As EventArgs) Handles tsbSummary.Click
        Call mnuSummary_Click(sender, e)
    End Sub

    Private Sub tsbFont_Click(sender As Object, e As EventArgs) Handles tsbFont.Click
        Call mnuFont_Click(sender, e)
    End Sub

    Private Sub tsbFontBackColor_Click(sender As Object, e As EventArgs) Handles tsbFontBackColor.Click
        Call mnuFontBackColor_Click(sender, e)
    End Sub

    Private Sub tsbClearPerson_Click(sender As Object, e As EventArgs) Handles tsbClearPerson.Click
        Call mnuClearPerson_Click(sender, e)
    End Sub

    Private Sub tsbClearAll_Click(sender As Object, e As EventArgs) Handles tsbClearAll.Click
        Call mnuClearAll_Click(sender, e)
    End Sub

    Private Sub tsbAbout_Click(sender As Object, e As EventArgs) Handles tsbAbout.Click
        Call mnuAbout_Click(sender, e)
    End Sub

    Private Sub tsbExit_Click(sender As Object, e As EventArgs) Handles tsbExit.Click
        Call mnuExit_Click(sender, e)
    End Sub
End Class
